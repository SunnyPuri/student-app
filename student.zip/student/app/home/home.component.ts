import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/home/home.component.html'
})
export class HomeComponent {
    public pageTitle: string = 'Welcome to Student App';
}
