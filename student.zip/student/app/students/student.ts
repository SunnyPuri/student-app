export interface IStudent {
    id: number;
    firstName: string;
    lastName: string;
    gender: string;
    mobile: number;
    email: string;
    skills?: string[];
}